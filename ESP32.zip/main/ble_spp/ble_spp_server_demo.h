/*
 * SPDX-FileCopyrightText: 2021 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 * DEFINES
 ****************************************************************************************
 */
// #define SUPPORT_HEARTBEAT
// #define SPP_DEBUG_MODE

#define spp_sprintf(s, ...) sprintf_j((char *)(s), sizeof((char *)(s)), ##__VA_ARGS__)
#define SPP_DATA_MAX_LEN (512)
#define SPP_CMD_MAX_LEN (20)
#define SPP_STATUS_MAX_LEN (20)
#define SPP_DATA_BUFF_MAX_LEN (2 * 1024)
/// Attributes State Machine
enum {
  SPP_IDX_SVC,

  SPP_IDX_SPP_DATA_RECV_CHAR,
  SPP_IDX_SPP_DATA_RECV_VAL,

  SPP_IDX_SPP_DATA_NOTIFY_CHAR,
  SPP_IDX_SPP_DATA_NTY_VAL,
  SPP_IDX_SPP_DATA_NTF_CFG,

  SPP_IDX_SPP_STATUS_CHAR,
  SPP_IDX_SPP_STATUS_VAL,
  SPP_IDX_SPP_STATUS_CFG,
  SPP_IDX_NB,
};
void ble_gap_gatt_spp_init(void);
uint8_t ble_spp_SendData(size_t size, uint8_t *temp);
extern bool ble_is_connected;
